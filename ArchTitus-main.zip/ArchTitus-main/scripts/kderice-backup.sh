#!/bin/bash

cp -r $HOME/.config/kitty $HOME/$SCRIPTHOME/configs/.config/kitty
konsave -s kde
konsave -e kde