# ArchTitus

Entrance script that launches children scripts for each phase of installation.

# Functions



