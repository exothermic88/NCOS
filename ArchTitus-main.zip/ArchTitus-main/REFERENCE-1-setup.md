# Setup

Configures installed system, installs base packages, and creates user. 

# Functions



