# Reference
**Library Files**
* [scripts/startup.sh](REFERENCE-startup.md)
* [scripts/0-preinstall.sh](REFERENCE-0-preinstall.md)
* [archtitus.sh](REFERENCE-archtitus.md)
* [scripts/1-setup.sh](REFERENCE-1-setup.md)
* [scripts/3-post-setup.sh](REFERENCE-3-post-setup.md)
* [scripts/2-user.sh](REFERENCE-2-user.md)
